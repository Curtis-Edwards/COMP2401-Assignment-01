#include <stdio.h>

// Read `main.c` for information about these forward declarations.
// Do NOT define the functionality here, but instead, define them below.
#define MAX_ENTRIES 16
#define C_OK  0
#define C_ERR_EMPTY_ARRAY  -1
#define C_ERR_INVALID_EMF  -2
#define C_ERR_INVALID_ROOM -3

// Do *not* place your function implementations right here; these are
// forward declarations, and are intended to tell the rest of the code
// that these functions will be found. It means we do not have to worry
// about the order that our functions are written in.
// You can use these "prototypes" or "signatures", and copy-paste them to 
// write your functions below, similar to the broken "sort_entries" function.
int get_entries(int ids[], float readings[]);
int print_entries(int ids[], float readings[], int size);
int sort_entries(int ids[], float readings[], int size);
int find_max_index(float readings[], int size);
int invalid_room(int id);
int invalid_reading(float reading);